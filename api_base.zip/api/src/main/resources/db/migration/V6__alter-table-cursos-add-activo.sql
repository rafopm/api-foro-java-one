alter table cursos add activo tinyint;
update cursos set activo = 1;