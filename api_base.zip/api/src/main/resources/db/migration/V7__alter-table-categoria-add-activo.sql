alter table Categorias add activo tinyint;
update Categorias set activo = 1;