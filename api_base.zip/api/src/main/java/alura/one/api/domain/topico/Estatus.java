package alura.one.api.domain.topico;

public enum Estatus {
    ACTIVO,
    CERRADO,
    ELIMINADO
}
