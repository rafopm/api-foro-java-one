package alura.one.api.domain.respuesta;

public enum Estatus {
    ACTIVA,
    PENDIENTE,
    EDITADA,
    RECHAZADA,
    ELIMINADA
}
